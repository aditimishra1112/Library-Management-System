-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0+deb9u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `username` varchar(5) DEFAULT NULL,
  `password` varchar(6) DEFAULT NULL,
  `role` tinyint(4) DEFAULT NULL,
  `name` varchar(5) DEFAULT NULL,
  `avt` varchar(16) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `datebirth` varchar(10) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `gmail` varchar(15) DEFAULT NULL
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--


/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('admin','admin',1,'','img/avt/avt.jpg',0,'','',''),('user1','123456',0,'user1','img/avt/avt1.jpg',1,'2000-12-23','0123443789','user1@gmail.com'),('user2','123456',0,'user2','img/avt/avt2.jpg',1,'2000-12-23','0195456789','user2@gmail.com'),('user3','123456',0,'user3','img/avt/avt3.jpg',0,'2000-12-23','0123493489','user3@gmail.com'),('user4','123456',0,'user4','img/avt/avt4.jpg',1,'2000-12-23','0193214789','user4@gmail.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `id` INTEGER PRIMARY KEY,
  `name` varchar(114) DEFAULT NULL,
  `img` varchar(19) DEFAULT NULL,
  `author` varchar(54) DEFAULT NULL,
  `category` tinyint(4) DEFAULT NULL,
  `publisher` varchar(69) DEFAULT NULL,
  `language` varchar(10) DEFAULT NULL,
  `total` tinyint(4) DEFAULT NULL,
  `current` tinyint(4) DEFAULT NULL,
  `position` varchar(3) DEFAULT NULL
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--


/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (10001,'Code: The Hidden Language of Computer Hardware and Software','img/book/book1.jpg','Charles Petzold',1,'Microsoft Press; 1st edition (October 11, 2000)','english',5,0,'F34'),(10002,'The Self-Taught Computer Scientist ','img/book/book2.jpg','Cory Althoff ',1,'Wiley; 1st edition (October 1, 2021)','english',4,1,'F36'),(10003,'The Chip : How Two Americans Invented the Microchip and Launched a Revolution','img/book/book3.jpg','T. R. Reid',1,'Random House Trade Paperbacks; Revised edition (October 9, 2001)','english',3,2,'F35'),(10004,'The Second Machine Age: Work, Progress, and Prosperity in a Time of Brilliant Technologies','img/book/book4.jpg','Erik Brynjolfsson',1,'giáo dục','english',2,0,'A37'),(10005,'The Innovators: How a Group of Hackers, Geniuses, and Geeks Created the Digital Revolution','img/book/book5.jpg','Walter Isaacson',1,'Walter Isaacson','english',3,2,'E12'),(10006,'A Programmers Guide to Computer Science: A virtual degree for the self-taught developer','img/book/book6.jpg','Dr. William M Springer II',1,'Jaxson Media; Illustrated edition (July 28, 2019)','english',3,1,'E54'),(10007,'A handbook for teacher research : From design to implementation','img/book/book7.jpg','Colin Lankshear, Michele Knobel',2,'Open University Press','english',3,2,'B34'),(10008,'A course in phonetics','img/book/book8.jpg',' Ladefoged, Peter',2,'Cengage Learning, 2011','english',3,2,'G54'),(10009,'Language: Its structure and use','img/book/book9.jpg','Finegan, Edward',2,'Thomson Wadsworth, c2004,p','english',3,2,'S34'),(10010,'An introduction to linguistic theory and language acquisition','img/book/book10.jpg','Crain, Stephen; Lillo-Martin, Diane C. (Diane Carolyn)',2,'Wiley, 1999','english',3,3,'G54'),(10011,'An introduction to functional grammar','img/book/book11.jpg','Zoe Erotopoulos',2,'Arnold, 2004','english',3,1,'C54'),(10012,'An introduction to pragmatics: Social action for language teachers','img/book/book12.jpg','Halliday, M. A. K. (Michael Alexander Kirkwood)',2,'University of Michigan Press, 2003','english',4,0,'D31'),(10013,'500 Activities for the Primary Classroom','img/book/book13.jpg','LoCastro, Virginia.',3,'Macmillan Education','english',3,1,'D43'),(10014,'The Economics Book','img/book/book14.jpg','Carol Read',3,'Dorling Kindersley, 2012','english',3,2,'Q21'),(10015,'Principles for Dealing with the Changing World Order: Why Nations Succeed and Fail','img/book/book15.jpg','Dorling Kindersley',3,'Avid Reader Press / Simon & Schuster; 1st edition (November 30, 2021)','english',3,3,'A02'),(10016,'Business Valuation: The Most Complete Guide on How to Value a Business Through Updated Financial Valuation Methods','img/book/book16.jpg','Ray Dalio',3,'EquaMoney Press (February 17, 2023)','english',3,2,'D87'),(10017,'Financial Management Essentials You Always Wanted To Know (Color) (Self Learning Management)','img/book/book17.jpg','Nathan S. Goodwin',3,'Vibrant Publishers (September 19, 2019)','english',3,2,'N21'),(10018,'The Psychology of Money: Timeless lessons on wealth, greed, and happiness','img/book/book18.jpg','Kalpesh Ashar',3,'Harriman House (September 8, 2020)','english',3,2,'A44'),(10019,'Millionaire Mindset','img/book/book19.jpg','Paperback',3,'Get Rich Books (February 22, 2023)','english',4,1,'A34'),(10020,'English Grammar for Students of Spanish: The Study Guide for Those Learning Spanish, 7th edition','img/book/book20.jpg','Reveal Riches',4,'Olivia & Hill Press; 7th edition (December 18, 2012)','english',3,3,'J78'),(10021,'FRENCH, ENGLISH GRAMMAR FOR STUDENTS OF FRENCH, 7TH ED','img/book/book21.jpg','Emily Spinelli',4,'Olivia & Hill Press; 7th edition (July 17, 2013)','english',3,2,'K51'),(10022,'French All-in-One For Dummies','img/book/book22.jpg','Jacqueline Morton',4,'For Dummies; 1st edition (October 9, 2012)','english',3,2,'F23'),(10023,'Easy French Step-By-Step: Master High-Frequency Grammar for French Proficiency--Fast','img/book/book23.jpg','The Experts at Dummies',4,'McGraw Hill; 1st edition (December 1, 2008)','english',3,3,'L44'),(10024,'French For Dummies 2nd Edition','img/book/book24.jpg','Myrna Bell Rochester',4,'For Dummies; 2nd edition (August 30, 2011)','english',3,2,'M34');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;


--
-- Table structure for table `borrower`
--

DROP TABLE IF EXISTS `borrower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower` (
  `id` INTEGER PRIMARY KEY,
  `username` varchar(5) DEFAULT NULL,
  `book_id` mediumint(9) DEFAULT NULL,
  `form` varchar(10) DEFAULT NULL,
  `to` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower`
--


/*!40000 ALTER TABLE `borrower` DISABLE KEYS */;
INSERT INTO `borrower` VALUES (1,'user1',10001,'2023-03-09','2023-03-24','borrowed'),(2,'user1',10002,'2023-02-09','2023-02-24','borrowed'),(3,'user2',10013,'2023-03-09','2023-03-24','borrowed'),(4,'user2',10019,'2023-02-09','2023-02-24','borrowed'),(5,'user3',10001,'2023-03-09','2023-03-24','borrowed'),(6,'user4',10004,'2023-03-09','2023-03-24','borrowed'),(7,'user4',10006,'2023-03-09','2023-03-24','borrowed'),(8,'user3',10012,'2023-03-09','2023-03-24','borrowed'),(9,'user2',10018,'2022-11-02','2022-11-24','returned'),(10,'user2',10008,'2022-11-02','2022-11-24','returned'),(11,'user3',10021,'2022-11-02','2022-11-24','returned'),(12,'user3',10011,'2022-11-02','2022-11-24','returned'),(13,'user4',10016,'2022-12-02','2022-12-24','returned'),(14,'user4',10012,'2022-12-02','2022-12-24','returned'),(15,'user2',10011,'2022-12-02','2022-12-24','returned'),(16,'user4',10002,'2022-12-02','2022-12-24','returned'),(17,'user2',10017,'2022-12-02','2022-12-24','returned'),(18,'user3',10022,'2023-01-02','2023-01-24','returned'),(19,'user1',10005,'2023-01-02','2023-01-24','returned'),(20,'user1',10003,'2023-01-02','2023-01-24','returned'),(21,'user1',10007,'2023-02-02','2023-03-24','returned'),(22,'user4',10024,'2023-02-02','2023-02-24','returned'),(23,'user1',10017,'2023-02-02','2023-03-24','returned'),(24,'user2',10001,'2023-02-02','2023-03-24','returned'),(25,'user4',10014,'2023-03-02','2023-03-24','returned'),(26,'user3',10016,'2023-03-02','2023-03-24','returned'),(27,'user1',10012,'2023-03-02','2023-03-24','returned'),(28,'user2',10026,'2023-03-02','2023-03-24','returned'),(29,'user1',10019,'2023-03-02','2023-03-24','returned'),(30,'user3',10009,'2023-03-02','2023-03-24','returned'),(31,'user1',10001,'','','processing'),(32,'user1',10002,'','','processing'),(33,'user2',10013,'','','processing'),(34,'user2',10019,'','','processing'),(35,'user3',10001,'','','processing'),(36,'user4',10004,'','','processing'),(37,'user4',10006,'','','processing'),(38,'user3',10012,'','','processing');
/*!40000 ALTER TABLE `borrower` ENABLE KEYS */;


--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` INTEGER PRIMARY KEY,
  `name` varchar(16) DEFAULT NULL
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--


/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Computer Science'),(2,'Electrical Electronics'),(3,'Civil Engineering'),(4,'Mechanical Engineering');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` INTEGER PRIMARY KEY,
  `user_id` varchar(5) DEFAULT NULL,
  `title` varchar(17) DEFAULT NULL,
  `content` varchar(56) DEFAULT NULL
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--


/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,'user1','test','More books should be added'),(2,'user2','test2 ','Easy to use'),(3,'user3','test3','Good Service');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


