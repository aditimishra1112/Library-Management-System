package com.abhinav.library.dbConnect;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBContext {
    public Connection getConnection() throws Exception {
        Class.forName("org.sqlite.JDBC");
        String url = "jdbc:sqlite::resource:db.sqlite3";
        return DriverManager.getConnection(url);
    }
}