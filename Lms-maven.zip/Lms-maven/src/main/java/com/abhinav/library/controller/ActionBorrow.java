/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abhinav.library.controller;

import com.abhinav.library.DAO.BookDAO;
import com.abhinav.library.DAO.BorrowerDAO;
import com.abhinav.library.entity.Borrower;
import com.abhinav.library.entity.Book;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 *
 * @author AMG
 */
public class ActionBorrow extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        if (session.getAttribute("username") == null) {
            resp.sendRedirect("Login");
            return;
        }
        
        String url= req.getParameter("url");
        url = url + "/Login";
        String bookid= req.getParameter("id");
        BorrowerDAO bdao= new BorrowerDAO();
        if (bdao.getBorrowerByBookId(session.getAttribute("username").toString(), Integer.parseInt(bookid)).getUsername() == null) {
            System.out.println("New User!!");
            //Update quantity book
            BookDAO bookdao= new BookDAO();
            Book book= bookdao.getBookById(Integer.parseInt(bookid));
            book.setCurrent(book.getCurrent()-1);
            bookdao.updateBook(book);
            //insert into borrower
            bdao.insertBorrower(session.getAttribute("username").toString(), Integer.parseInt(bookid));
            resp.sendRedirect(url);
        } else {
            System.out.println("Old User!!");
            resp.sendRedirect(url);
        }
    }

}
