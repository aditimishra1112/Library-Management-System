import os, shutil, sys, sqlite3

plat = sys.platform
cwd = os.getcwd()

if os.path.exists("src/main/resources/db.sqlite3"):
    os.remove("src/main/resources/db.sqlite3")
con = sqlite3.connect('src/main/resources/db.sqlite3')
cur = con.cursor()
with open('src/main/resources/table.sql', 'r', encoding="utf8") as f:
    sql = f.read()
    cur.executescript(sql)
con.commit()
con.close()

# Configure JDK
if plat == "linux":
    if not os.path.exists("openjdk-20.0.1_windows-x64_bin.zip"):
        os.system("wget https://download.java.net/java/GA/jdk20.0.1/b4887098932d415489976708ad6d1a4b/9/GPL/openjdk-20.0.1_windows-x64_bin.zip")
        os.system("unzip openjdk-20.0.1_windows-x64_bin.zip")
    JAVA_HOME = f"{cwd}/jdk-20.0.1"
else:
    JAVA_HOME = "C:/jdk-20.0.1"

if plat == "linux":
    os.system("export JAVA_HOME=\"{JAVA_HOME}\"")
else:
    os.environ["JAVA_HOME"] = JAVA_HOME

# Configure Maven and build project
if plat == "linux":
    if not os.path.exists("apache-maven-3.9.2-bin.zip"):
        os.system("wget https://dlcdn.apache.org/maven/maven-3/3.9.2/binaries/apache-maven-3.9.2-bin.zip")
        os.system("unzip apache-maven-3.9.2-bin.zip")
    MAVEN_LOCATION=f"{cwd}/apache-maven-3.9.2"
else:
    MAVEN_LOCATION="C:/Users/abhin/Downloads/apache/apache-maven-3.9.2"

if os.path.exists("target"):
    shutil.rmtree("target")

os.system(f"{MAVEN_LOCATION}/bin/mvn package -f pom.xml")

# Configure Tomcat and serve project
if plat == "linux":
    if not os.path.exists("apache-tomcat-8.5.89.zip"):
        os.system("wget https://dlcdn.apache.org/tomcat/tomcat-8/v8.5.89/bin/apache-tomcat-8.5.89.zip")
        os.system("unzip apache-tomcat-8.5.89.zip")
    TOMCAT_LOCATION=f"{cwd}/apache-tomcat-8.5.89"
else:
    TOMCAT_LOCATION="C:/Users/abhin/Downloads/apache/apache-tomcat-8.5.89"

if plat == "linux":
    os.system("export CATALINA_HOME=\"{TOMCAT_LOCATION}\"")
else:
    os.environ["CATALINA_HOME"] = TOMCAT_LOCATION

shutil.copyfile("tomcat-users.xml", f"{TOMCAT_LOCATION}/conf/tomcat-users.xml")
shutil.copyfile("context.xml", f"{TOMCAT_LOCATION}/webapps/manager/META-INF/context.xml")
shutil.copyfile("target/library-1.0.war", f"{TOMCAT_LOCATION}/webapps/library-1.0.war")

if plat == "linux":
    os.system(f"find {TOMCAT_LOCATION}/bin -type f -iname '*.sh' -exec chmod a+rx" + " '{}' \;")
    os.system(f"{TOMCAT_LOCATION}/bin/shutdown.sh")
    if os.path.exists(f"{TOMCAT_LOCATION}/webapps/library-1.0"):
        shutil.rmtree(f"{TOMCAT_LOCATION}/webapps/library-1.0")
else:
    os.system(f"{TOMCAT_LOCATION}/bin/shutdown")
    if os.path.exists(f"{TOMCAT_LOCATION}/webapps/library-1.0"):
        shutil.rmtree(f"{TOMCAT_LOCATION}/webapps/library-1.0")

if plat == "linux":
    os.system(f"find {TOMCAT_LOCATION}/bin -type f -iname '*.sh' -exec chmod a+rx" + " '{}' \;")
    os.system(f"{TOMCAT_LOCATION}/bin/startup.sh")
else:
    os.system(f"{TOMCAT_LOCATION}/bin/startup")

# http://localhost:8080/library-1.0/
# ./apache-tomcat-8.5.89/bin/shutdown.sh to shutdown server on linux